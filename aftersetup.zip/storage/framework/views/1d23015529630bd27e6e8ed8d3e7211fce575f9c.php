<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset(asset_path('modules/language/css/style.css'))); ?>" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>

    <?php
        $form_type = '';
        if(\Session::has('language_form')){
            $form_type = \Session::get('language_form');
        }


    ?>
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="box_header common_table_header">
                        <div class="main-title d-flex">
                            <h3 class="mb-0 mr-30 mb_xs_15px mb_sm_20px"><?php echo e(__('language.language_list')); ?></h3>
                            <?php if(permissionCheck('languages.store')): ?>
                                <ul class="d-flex">
                                    <li><a class="primary-btn radius_30px mr-10 fix-gr-bg" href="" id="add_new_btn"><i class="ti-plus"></i><?php echo e(__('language.add_new_language')); ?></a></li>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="QA_section QA_section_heading_custom check_box_table">
                        <div class="QA_table ">
                            <!-- table-responsive -->
                            <div class="">
                                <table class="table Crm_table_active3">
                                    <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('common.sl')); ?></th>
                                        <th scope="col"><?php echo e(__('common.name')); ?></th>
                                        <th scope="col"><?php echo e(__('language.code')); ?></th>
                                        <th scope="col"><?php echo e(__('language.RTL')); ?>/<?php echo e(__('language.LTL')); ?></th>
                                        <th scope="col"><?php echo e(__('common.active')); ?></th>
                                        <th scope="col"><?php echo e(__('common.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e(getNumberTranslate($key+1)); ?></th>
                                            <td><?php echo e($language->name); ?></td>
                                            <td><?php echo e($language->code); ?></td>
                                            <td>

                                                <span class="primary-btn radius_30px mr-10 fix-gr-bg rtl_ltl_btn"> <?php if($language->rtl == 1): ?> <?php echo e(__('language.RTL')); ?> <?php else: ?> <?php echo e(__('language.LTL')); ?> <?php endif; ?></span>
                                            </td>
                                            <td>
                                                <label class="switch_toggle" for="active_checkbox<?php echo e($language->id); ?>">
                                                    <input type="checkbox" id="active_checkbox<?php echo e($language->id); ?>" <?php if($language->status == 1): ?> checked <?php endif; ?> <?php if(permissionCheck('languages.update') && $language->id != 19): ?> value="<?php echo e($language->id); ?>" data-id="<?php echo e($language->id); ?>" class="status_change" <?php else: ?> disabled <?php endif; ?>>
                                                    <div class="slider round"></div>
                                                </label>
                                            </td>
                                            <td>
                                                <!-- shortby  -->
                                                <div class="dropdown CRM_dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button"
                                                            id="dropdownMenu2" data-toggle="dropdown"
                                                            aria-haspopup="true"
                                                            aria-expanded="false">
                                                        <?php echo e(__('common.select')); ?>

                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                                                        <?php if(permissionCheck('languages.update') && $language->id != 19): ?>
                                                            <a href="" class="dropdown-item edit_language" data-id="<?php echo e($language->id); ?>"><?php echo e(__('common.edit')); ?></a>
                                                        <?php endif; ?>
                                                        <?php if(permissionCheck('language.translate_view')): ?>
                                                            <a href="<?php echo e(route('language.translate_view', $language->id)); ?>" class="dropdown-item edit_brand"><?php echo e(__('general_settings.Translation')); ?></a>
                                                        <?php endif; ?>
                                                        <?php if(permissionCheck('languages.destroy') && $language->id > 114): ?>
                                                            <a  data-id="<?php echo e($language->id); ?>" class="dropdown-item delete_language"><?php echo e(__('common.delete')); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <!-- shortby  -->
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="edit_form">

    </div>
    <div id="add_laguage_modal">
        <div class="modal fade admin-query" id="language_add">
            <div class="modal-dialog modal_800px modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><?php echo e(__('language.add_new_language')); ?></h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <i class="ti-close "></i>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form action="<?php echo e(route('languages.store')); ?>" method="POST" id="language_addForm">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-xl-12">
                                    <div class="primary_input mb-25">
                                        <label class="primary_input_label" for=""><?php echo e(__('common.name')); ?> <span class="text-danger">*</span></label>
                                        <input name="name" id="name" class="primary_input_field name" placeholder="<?php echo e(__('common.name')); ?>" value="<?php echo e(old('name')); ?>" type="text">
                                        <span class="text-danger" id="error_name"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="primary_input mb-25">
                                        <label class="primary_input_label" for=""><?php echo e(__('language.code')); ?> <span class="text-danger">*</span></label>
                                        <input name="code" id="code" class="primary_input_field name" placeholder="<?php echo e(__('language.code')); ?>" value="<?php echo e(old('code')); ?>" type="text">
                                        <span class="text-danger" id="error_code"><?php echo e($errors->first('code')); ?></span>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="primary_input mb-25">
                                        <label class="primary_input_label" for=""><?php echo e(__('language.native_name')); ?> <span class="text-danger">*</span></label>
                                        <input name="native" id="native" class="primary_input_field name" placeholder="<?php echo e(__('language.native_name')); ?>" value="<?php echo e(old('native')); ?>" type="text">
                                        <span class="text-danger" id="error_native"><?php echo e($errors->first('native')); ?></span>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="primary_input">
                                        <label class="primary_input_label" for=""><?php echo e(__('language.RTL')); ?>/<?php echo e(__('language.LTL')); ?></label>
                                        <ul id="theme_nav" class="permission_list sms_list ">
                                            <li>
                                                <label data-id="bg_option" class="primary_checkbox d-flex mr-12">
                                                    <input name="rtl_ltl" value="0" checked class="active"
                                                        type="radio">
                                                    <span class="checkmark"></span>
                                                </label>
                                                <p><?php echo e(__('language.LTL')); ?></p>
                                            </li>
                                            <li>
                                                <label data-id="color_option" class="primary_checkbox d-flex mr-12">
                                                    <input name="rtl_ltl" value="1" class="de_active" type="radio">
                                                    <span class="checkmark"></span>
                                                </label>
                                                <p><?php echo e(__('language.RTL')); ?></p>
                                            </li>
                                        </ul>
                                        <span class="text-danger" id="status_error"></span>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="primary_input">
                                        <label class="primary_input_label" for=""><?php echo e(__('common.status')); ?></label>
                                        <ul id="theme_nav" class="permission_list sms_list ">
                                            <li>
                                                <label data-id="bg_option" class="primary_checkbox d-flex mr-12">
                                                    <input name="status" value="1" checked class="active"
                                                        type="radio">
                                                    <span class="checkmark"></span>
                                                </label>
                                                <p><?php echo e(__('common.active')); ?></p>
                                            </li>
                                            <li>
                                                <label data-id="color_option" class="primary_checkbox d-flex mr-12">
                                                    <input name="status" value="0" class="de_active" type="radio">
                                                    <span class="checkmark"></span>
                                                </label>
                                                <p><?php echo e(__('common.inactive')); ?></p>
                                            </li>
                                        </ul>
                                        <span class="text-danger" id="status_error"></span>
                                    </div>
                                </div>

                                <div class="col-lg-12 text-center">
                                    <div class="d-flex justify-content-center pt_20">
                                        <button type="submit" class="primary-btn semi_large2 fix-gr-bg" id="save_button_parent"><i class="ti-check"></i><?php echo e(__('common.save')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('backEnd.partials.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
        (function($){
            "use strict";

            <?php if(count($errors) > 0 && $form_type == 'store_form'): ?>
                $('#language_add').modal('show');

            <?php endif; ?>

            $( document ).ready(function() {

                $(document).on('click', '#add_new_btn', function(event){
                    event.preventDefault();
                    $('#language_add').modal('show');
                });

                $(document).on('click', '.edit_language', function(event){
                    event.preventDefault();
                    $('#pre-loader').removeClass('d-none');
                    let id = $(this).data('id');
                    $.post('<?php echo e(route('languages.edit')); ?>', {_token:'<?php echo e(csrf_token()); ?>', id:id}, function(data){
                        $('#edit_form').html(data);
                        $('#Item_Edit').modal('show');
                        $('#pre-loader').addClass('d-none');
                    });

                });

                $(document).on('click', '.delete_language', function(event){
                    event.preventDefault();
                    let id = $(this).data('id');
                    let baseUrl = $('#url').val();
                    let url = baseUrl + '/setup/language/destroy/' + id;
                    confirm_modal(url);
                });

                $(document).on('change', '.status_change', function(event){
                    event.preventDefault();
                    let status = 0;
                    if($(this).prop('checked')){
                        status = 1;
                    }
                    else{
                        status = 0;
                    }
                    let id = $(this).data('id');
                    if(id == 19){
                        toastr.error("<?php echo e(__('common.error_message')); ?>");
                        return false;
                    }
                    $('#pre-loader').removeClass('d-none');
                    let formData = new FormData();
                    formData.append('_token', "<?php echo e(csrf_token()); ?>");
                    formData.append('id', id);
                    formData.append('status', status);

                    $.ajax({
                        url: "<?php echo e(route('languages.update_active_status')); ?>",
                        type: "POST",
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function(response) {
                            toastr.success("<?php echo e(__('common.updated_successfully')); ?>","<?php echo e(__('common.success')); ?>");
                            $('#pre-loader').addClass('d-none');
                        },
                        error: function(response) {
                            if(response.responseJSON.error){
                                toastr.error(response.responseJSON.error ,"<?php echo e(__('common.error')); ?>");
                                $('#pre-loader').addClass('d-none');
                            }else{
                                toastr.error("<?php echo e(__('common.error_message')); ?>");
                                $('#pre-loader').addClass('d-none');
                            }
                        }
                    });

                });

                $(document).on('change', '.rtl_status_change', function(event){
                    event.preventDefault();
                    let status = 0;
                    if($(this).prop('checked')){
                        status = 1;
                    }
                    else{
                        status = 0;
                    }
                    let id = $(this).data('id');
                    $('#pre-loader').removeClass('d-none');
                    let formData = new FormData();
                    formData.append('_token', "<?php echo e(csrf_token()); ?>");
                    formData.append('id', id);
                    formData.append('status', status);

                    $.ajax({
                        url: "<?php echo e(route('languages.update_rtl_status')); ?>",
                        type: "POST",
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function(response) {
                            toastr.success("<?php echo e(__('common.updated_successfully')); ?>","<?php echo e(__('common.success')); ?>");
                            $('#pre-loader').addClass('d-none');
                        },
                        error: function(response) {
                            toastr.error("<?php echo e(__('common.error_message')); ?>");
                            $('#pre-loader').addClass('d-none');
                        }
                    });

                });

                $(document).on('submit', '#language_addForm', function(event){

                    $('#error_name').text("");
                    $('#error_code').text("");
                    $('#error_native').text("");

                    let name = $('#name').val();
                    let code = $('#code').val();
                    let native = $('#native').val();
                    let empty_check = 0;

                    if(name == ''){
                        $('#error_name').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_check = 1;
                    }
                    if(code == ''){
                        $('#error_code').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_check = 1;
                    }
                    if(native == ''){
                        $('#error_native').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_check = 1;
                    }
                    if(empty_check == 1){
                        event.preventDefault();
                    }
                });

                $(document).on('submit', '#languageEditForm', function(event){

                    $('#error_edit_name').text("");
                    $('#error_edit_code').text("");
                    $('#error_edit_native').text("");

                    let edit_name = $('#edit_name').val();
                    let edit_code = $('#edit_code').val();
                    let edit_native = $('#edit_native').val();
                    let empty_edit_check = 0;

                    if(edit_name == ''){
                        $('#error_edit_name').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_edit_check = 1;
                    }
                    if(edit_code == ''){
                        $('#error_edit_code').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_edit_check = 1;
                    }
                    if(edit_native == ''){
                        $('#error_edit_native').text("<?php echo e(__('validation.this_field_is_required')); ?>");
                        empty_edit_check = 1;
                    }
                    if(empty_edit_check == 1){
                        event.preventDefault();
                    }
                });

            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yoursoftwaredemo/ecom.yoursoftwaredemo.com/Modules/Language/Resources/views/languages/index.blade.php ENDPATH**/ ?>