<?php
return [
    'Expense' => 'Expense',
    'New Expense' => 'New Expense',
    'Edit Expense' => 'Edit Expense',
    'The requested expense is not found' => 'The requested expense is not found',
    'The requested expense deleted successful' => 'The requested expense deleted successful',
    'The requested expense created successful' => 'The requested expense created successful',
    'The requested expense updated successful' => 'The requested expense updated successful'
];
