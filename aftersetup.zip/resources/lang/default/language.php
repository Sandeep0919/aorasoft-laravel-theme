<?php return
    [
        'language_list' => 'Language List',
        'add_new_language' => 'Add New Language',
        'code' => 'Code',
        'RTL' => 'RTL',
        'LTL' => 'LTL',
        'Language Settings' => 'Language Settings',
        'native_name' => 'Native Name',
        'edit_language_info' => 'Edit Language Info',
        'translation' => 'Translation',
        'select_translatable_file' => 'Select Translatable File',
        'key' => 'Key',
        'value' => 'Value'
    ];
