<?php
return [
    "You cann\'t delete an income which has child element" => 'You cann\'t delete an income which has child element',
    'Incomes' => 'Incomes',
    'New Income' => 'New Income',
    'The requested income is not found' => 'The requested income is not found',
    'The requested income deleted successful' => 'The requested income deleted successful',
    'The requested income created successful' => 'The requested income created successful',
    'The requested income updated successful' => 'The requested income updated successful',
    'Edit Income' => 'Edit Income'
];
