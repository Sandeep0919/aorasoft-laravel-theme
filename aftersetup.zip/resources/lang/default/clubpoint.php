<?php return [
    'my_points' => 'My Points',
    'Order_code'=> 'Order Code',
    'point' => 'Point',
    'wallet_money'=>'Wallet Money',
    'converted_now'=>'Convert Now',
    'exchange_rate'=>'Exchange rate',
    'pts'=>'pts',
    'club_point'=>'Club Point',
    'set_product_point'=>'Set Product Point',
    'user_product_point'=>'User Product Point',
    'multiple' => 'Multiple',
    'Set Point'=>'Set Point',
    'set_point' => 'Set Point',
    'piint_convert_refund_date_over' => '(Point Convert Refund Date Over)',
    'total' => 'Total',
    
];
