<?php
return [
    'contact_mail' => 'Contact Mail',
    'contact_mail_list' => 'Contact Mail List',
    'contact_request' => 'Contact Request'
];
