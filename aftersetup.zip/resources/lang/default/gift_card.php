<?php
 return[
    'section' => 'Section',
    'gift_card_value' => 'Gift Card Value',
    'selling_price' => 'Selling Price',
    'discount_type' => 'Discount Type',
    'discount_amount' => 'Discount Amount',
    'expire_date' => 'Expire Date',
    'number_of_gift_card' => 'Number Of Gift Card',
    'coupon_code' => 'Coupon Code',
    'manual_coupon_code_input' => 'Manual Coupon Code Input',
    'bulk_coupon_code_input' => 'Bulk Coupon Code input',
    'gift_selling_price' => 'Gift Selling Price',
    'gift_selling_coupon' => 'Gift Selling Coupon',
    'gift_discount_amount' => 'Gift Card Discount Amount',
    'gift_expire_date' => 'Gift Card Expire Date',
    'drop_file_here_to_upload' => 'Drop File To Upload',
    'or_drag' => 'Or Drag',
    'browse_files' => 'Browse Files',

 ];