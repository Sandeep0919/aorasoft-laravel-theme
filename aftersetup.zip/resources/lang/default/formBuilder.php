<?php
return [
    'form_builder' => 'Form Builder',
    'forms' => 'Forms',
    'terms_page_link' => 'Terms Page Link',
    'privacy_policy_page_link' => 'Privacy Policy Page Link',
    'form' => 'Form',
    'form_create_successfully' => 'Form Create Successfully',
];

