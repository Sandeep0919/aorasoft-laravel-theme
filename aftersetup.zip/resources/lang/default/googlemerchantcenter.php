<?php
return [
    'Google Merchant Center' => 'Google Merchant Center',
    'Products Export' => 'Products Export',
    'Click here go to Google Merchant Center google product category Link' => 'Click here go to Google Merchant Center google product category Link'
];