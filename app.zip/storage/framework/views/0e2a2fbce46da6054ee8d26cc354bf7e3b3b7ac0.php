<div class="">
    <table class="table" id="approveReviewTable">
        <thead>
            <tr>
                <th scope="col" width="10%"><?php echo e(__('common.sl')); ?></th>
                <th scope="col" width="10%"><?php echo e(__('review.rating')); ?></th>
                <th scope="col" width="45%"><?php echo e(__('review.customer_feedback')); ?></th>
                <th scope="col" width="15%"><?php echo e(__('review.customer_time')); ?></th>
                <th scope="col" width="20%"><?php echo e(__('review.approve')); ?><br>
                    
                </th>
            </tr>
        </thead>
        
    </table>
</div>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/Review/Resources/views/product_review/components/pending_list.blade.php ENDPATH**/ ?>