<div class="">

    <table class="table" id="cardTable">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__('common.sl')); ?></th>
                <th scope="col"><?php echo e(__('common.name')); ?></th>
                <th scope="col"><?php echo e(__('product.SKU')); ?></th>
                <th scope="col"><?php echo e(__('product.thumbnail_image')); ?></th>
                <th scope="col"><?php echo e(__('product.selling_price')); ?></th>
                <th scope="col"><?php echo e(__('common.number_of_sale')); ?></th>
                <th scope="col"><?php echo e(__('common.status')); ?></th>
                <th scope="col"><?php echo e(__('common.action')); ?></th>
            </tr>
        </thead>

    </table>
</div>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/GiftCard/Resources/views/giftcard/components/_list.blade.php ENDPATH**/ ?>