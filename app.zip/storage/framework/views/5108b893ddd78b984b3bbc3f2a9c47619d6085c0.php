<table class="table" id="inactiveCustomerTable">
    <thead>
        <tr>
            <th><?php echo e(__('common.sl')); ?></th>
            <th><?php echo e(__('common.avatar')); ?></th>
            <th><?php echo e(__('common.name')); ?></th>
            <th><?php echo e(__('common.email')); ?></th>
            <th><?php echo e(__('common.phone')); ?></th>
            <th><?php echo e(__('common.is_active')); ?></th>
            <th><?php echo e(__('common.wallet_balance')); ?></th>
            <th><?php echo e(__('common.total_orders')); ?></th>
            <th><?php echo e(__('common.action')); ?></th>
        </tr>
    </thead>
    
</table>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/Customer/Resources/views/customers/components/in_active_lists.blade.php ENDPATH**/ ?>