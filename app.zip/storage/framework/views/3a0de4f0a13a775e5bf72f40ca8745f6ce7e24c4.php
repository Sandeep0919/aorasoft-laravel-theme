<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="<?php echo e(asset(asset_path('modules/appearance/css/theme.css'))); ?>" />

<style>
    .text-length-1 {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
    }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="box_header">
                        <div class="main-title d-flex justify-content-between">
                            <h3 class="mb-0 mr-30"><?php echo e(__('appearance.themes')); ?></h3>
                            <?php if(permissionCheck('appearance.themes.store')): ?>
                                <ul class="d-flex">
                                <li><a class="primary-btn radius_30px mr-10 fix-gr-bg text-white" href="<?php echo e(route('appearance.themes.create')); ?>" dusk="Add New"><i class="ti-plus"></i><?php echo e(__('common.add_new')); ?></a></li>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="row">

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 item_section">
                            <div class="card default_card_border theme_full_100">

                                <div class="card-body screenshot p-0 flex-fill">
                                    <div class="single_item_img_div">
                                        <img src="<?php echo e(showImage($activeTheme->image)); ?>" alt="">
                                    </div>

                                </div>
                                <div class="card-footer">
                                    <div class="row">
                                        <div class="col-lg-5">
                                            <h4><?php echo e($activeTheme->name); ?></h4>
                                        </div>
                                        <?php if($activeTheme->is_active !=1 ): ?>
                                        <div class="col-lg-7 footer_div">
                                            <div class="row btn_div">
                                                <div class="col-md-5 col-sm-12">
                                                    <?php if(permissionCheck('appearance.themes.active')): ?>
                                                        <form action="<?php echo e(route('appearance.themes.active')); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($activeTheme->id); ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-secondary Active_btn"><?php echo e(__('common.active')); ?></button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-7 col-sm-12 p_l_0">
                                                <a class="btn btn-sm btn-outline-secondary Active_btn" target="_blank" href="<?php echo e($activeTheme->live_link); ?>"><?php echo e(__('appearance.live_preview')); ?></a>
                                                </div>
                                            </div>

                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if(permissionCheck('appearance.themes.show')): ?>
                                    <div class="text-center detail_btn">
                                    <h4><a href="<?php echo e(route('appearance.themes.show',$activeTheme->id)); ?>"><?php echo e(__('appearance.theme_details')); ?></a></h4>
                                    </div>
                                <?php endif; ?>
                            </div>


                        </div>

                        <?php $__currentLoopData = $ThemeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 item_section">
                            <div class="card theme_full_100">

                                <div class="card-body screenshot p-0 flex-fill">
                                    <div class="single_item_img_div">
                                        <img src="<?php echo e(showImage($item->image)); ?>" alt="">
                                    </div>

                                </div>
                                <div class="card-footer">
                                    <div class="row align-items-center align-items-lg-start">
                                        <div class="col-md-3">
                                            <h4 class="text-length-1 mb-0"><?php echo e($item->name); ?></h4>
                                        </div>

                                        <div class="col-md-9 footer_div d-flex justify-content-end  ">


                                            <div class="row">
                                                <div class="col-md-5 col-sm-12 text-center">
                                                    <?php if(!empty($item->purchase_code) || $item->name=='default' || empty($item->item_code)): ?>
                                                        <form action="<?php echo e(route('appearance.themes.active')); ?>"
                                                              method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                            <button type="submit"
                                                                    class="primary-btn radius_30px mr-10   fix-gr-bg text-white pl-3 pr-3">
                                                                <?php echo e(__('common.active')); ?>

                                                            </button>
                                                        </form>
                                                        <?php if(!empty($item->item_code)): ?>
                                                            <?php if ($__env->exists('service::license.revoke-theme', ['name' =>$item->name])) echo $__env->make('service::license.revoke-theme', ['name' =>$item->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <a class=" verifyBtn primary-btn radius_30px mr-10   fix-gr-bg text-white pl-3 pr-3"
                                                           data-toggle="modal" data-id="<?php echo e(@$item->name); ?>"
                                                           data-target="#Verify"
                                                           href="#">   <?php echo e(__('appearance.verify')); ?></a>
                                                    <?php endif; ?>
    
                                                </div>
                                                <div style="padding-left: 0;" class="col-md-7 col-sm-12">
                                                    <a class="primary-btn radius_30px mr-10   fix-gr-bg text-white pl-3 pr-3" target="_blank" href="<?php echo e($item->live_link); ?>"><?php echo e(__('appearance.live_preview')); ?></a>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <?php if(permissionCheck('appearance.themes.show')): ?>
                                    <div class="text-center detail_btn">
                                        <h4><a href="<?php echo e(route('appearance.themes.show',$item->id)); ?>" dusk="view details"><?php echo e(__('appearance.theme_details')); ?></a></h4>
                                    </div>
                                <?php endif; ?>
                            </div>


                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(permissionCheck('appearance.themes.store')): ?>
                            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12">
                                <a href="<?php echo e(route('appearance.themes.create')); ?>" class="theme_full_100 d-flex align-items-center justify-content-center " id="add_new" >
                                    <span id="plus"><i class="fas fa-plus"></i></span>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade admin-query" id="Verify">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Module Verification</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;
                        </button>
                    </div>
    
                    <div class="modal-body">
                        <?php echo e(Form::open(['id'=>"content_form",'class' => 'form-horizontal', 'files' => true, 'route' => 'service.theme.install', 'method' => 'POST'])); ?>

                        <input type="hidden" name="name" value="" id="moduleName">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="user">Envato Email Address :</label>
                            <input type="text" class="form-control " name="envatouser"
                                   required="required"
                                   placeholder="Enter Your Envato Email Address"
                                   value="<?php echo e(old('envatouser')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="purchasecode">Envato Purchase Code:</label>
                            <input type="text" class="form-control" name="purchase_code"
                                   required="required"
                                   placeholder="Enter Your Envato Purchase Code"
                                   value="<?php echo e(old('purchasecode')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="domain">Installation Path:</label>
                            <input type="text" class="form-control"
                                   name="installationdomain" required="required"
                                   placeholder="Enter Your Installation Domain"
                                   value="<?php echo e(url('/')); ?>" readonly>
                        </div>
                        <div class="row mt-40">
                            <div class="col-lg-12 text-center">
                                <button class="primary-btn fix-gr-bg submit">
                                    <span class="ti-check"></span>
                                    <?php echo e(__('setting.Verify')); ?>

                                </button>
                                <button type="button" class="primary-btn fix-gr-bg submitting" style="display: none">
                                    <i class="fas fa-spinner fa-pulse"></i>
                                    Verifying
                                </button>
                            </div>
                        </div>
    
                        <?php echo e(Form::close()); ?>

                    </div>
    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('public/backend/js/module.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/vendor/spondonit/js/parsley.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/vendor/spondonit/js/function.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/vendor/spondonit/js/common.js')); ?>"></script>
    <script type="text/javascript">
        _formValidation('content_form');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/Appearance/Resources/views/theme/index.blade.php ENDPATH**/ ?>