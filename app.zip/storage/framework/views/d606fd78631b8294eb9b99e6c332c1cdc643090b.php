<div class="">
    
    <table class="table" id="approveReviewTable">
        <thead>
            <tr>
                <th scope="col" width="10%"><?php echo e(__('common.sl')); ?></th>
                <th scope="col" width="15%"><?php if(isModuleActive('MultiVendor')): ?><?php echo e(__('common.seller')); ?><?php else: ?> <?php echo e(__('common.company_info')); ?> <?php endif; ?></th>
                <th scope="col" width="15%"><?php echo e(__('review.rating')); ?></th>
                <th scope="col" width="30%"><?php echo e(__('review.customer_feedback')); ?></th>
                <th scope="col" width="15%"><?php echo e(__('review.customer_time')); ?></th>
                <th scope="col" width="15%"><?php echo e(__('review.approve')); ?><br>
                    
                </th>
            </tr>
        </thead>
        
    </table>
</div>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/Review/Resources/views/seller_review/components/pending_list.blade.php ENDPATH**/ ?>