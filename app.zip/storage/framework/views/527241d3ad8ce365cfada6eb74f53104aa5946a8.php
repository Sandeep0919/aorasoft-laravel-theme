<div class="">

    <table class="table" id="digitalcardTable">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__('common.sl')); ?></th>
                <th scope="col"><?php echo e(__('common.name')); ?></th>
                <th scope="col"><?php echo e(__('product.thumbnail_image')); ?></th>
                <th scope="col"><?php echo e(__('gift_card.gift_card_value')); ?></th>
                <th scope="col"><?php echo e(__('gift_card.gift_selling_price')); ?></th>
                <th scope="col"><?php echo e(__('gift_card.number_of_gift_card')); ?></th>
                <th scope="col"><?php echo e(__('gift_card.gift_selling_coupon')); ?></th>
                <th scope="col"><?php echo e(__('common.action')); ?></th>
            </tr>
        </thead>

    </table>
</div>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/GiftCard/Resources/views/giftcard/components/_giftcard_list.blade.php ENDPATH**/ ?>