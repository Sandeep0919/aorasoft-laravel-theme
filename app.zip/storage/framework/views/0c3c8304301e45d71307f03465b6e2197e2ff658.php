

<div class="logo_div">
    <img class="mini_logo img-size" src="<?php echo e(showImage($customer->avatar != null?$customer->avatar:'frontend/default/img/avatar.jpg')); ?>" alt="">
</div>
<?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/Customer/Resources/views/customers/components/_avatar_td.blade.php ENDPATH**/ ?>