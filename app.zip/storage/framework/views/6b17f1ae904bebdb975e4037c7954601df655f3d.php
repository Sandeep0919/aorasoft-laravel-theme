<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset(asset_path('modules/giftcard/css/style.css'))); ?>" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
<section class="admin-visitor-area up_st_admin_visitor">
    <?php if(permissionCheck('admin.giftcard.delete')): ?>
        <?php echo $__env->make('backEnd.partials._deleteModalForAjax',['item_name' => __('common.gift_card')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(permissionCheck('admin.giftcard.digital_gift_delete')): ?>
        <?php echo $__env->make('backEnd.partials._deleteModalForAjax',['item_name' => __('common.digital_gift_card'),'form_id' =>
        'digital_gift_card_delete_form','modal_id' => 'digital_gift_card_delete_modal', 'delete_item_id' => 'digital_gift_card_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-md-12 mb-20">
                <div class="box_header_right">
                    <div class="float-lg-right float-none pos_tab_btn justify-content-end">
                        <ul class="nav nav_list" role="tablist">
                            <?php if(permissionCheck('admin.giftcard.get-data')): ?>
                            <li class="nav-item">
                                <a class="nav-link active show" href="#order_processing_data" role="tab" data-toggle="tab" id="gift_card" aria-selected="true"><?php echo e(__('product.redeem_card')); ?> <?php echo e(__('common.list')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#digitalgiftcard" role="tab" data-toggle="tab" id="digital_gift_card" aria-selected="true"><?php echo e(__('common.gift_card')); ?> <?php echo e(__('common.list')); ?></a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-12">
                <div class="white_box_30px mb_30">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active show" id="order_processing_data">
                            <div class="box_header common_table_header ">
                                <div class="main-title d-md-flex">
                                    <h3 class="mb-0 mr-30 mb_xs_15px mb_sm_20px"><?php echo e(__('product.redeem_card')); ?> <?php echo e(__('common.list')); ?></h3>
                                    <?php if(permissionCheck('admin.giftcard.create')): ?>
                                    <ul class="d-flex">
                                        <li><a href="<?php echo e(route('admin.giftcard.create')); ?>" class="primary-btn radius_30px mr-10 fix-gr-bg"><i class="ti-plus"></i><?php echo e(__('common.add_new')); ?></a></li>
                                        <?php if(permissionCheck('admin.giftcard.bulk_gift_card_upload_page')): ?>
                                        <li><a class="primary-btn radius_30px mr-10 fix-gr-bg" href="<?php echo e(route('admin.giftcard.bulk_gift_card_upload_page')); ?>"><i class="ti-plus"></i><?php echo e(__('product.bulk_upload')); ?></a></li>
                                        <?php endif; ?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="QA_section QA_section_heading_custom check_box_table">
                                <div class="QA_table">
                                    <div id="item_table">
                                        <?php echo $__env->make('giftcard::giftcard.components._list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="digitalgiftcard">
                            <div class="box_header common_table_header ">
                                <div class="main-title d-md-flex">
                                    <h3 class="mb-0 mr-30 mb_xs_15px mb_sm_20px"><?php echo e(__('product.gift_card')); ?> <?php echo e(__('common.list')); ?></h3>
                                    <?php if(permissionCheck('admin.giftcard.create')): ?>
                                    <ul class="d-flex">
                                        <li><a href="<?php echo e(route('admin.giftcard.create')); ?>" class="primary-btn radius_30px mr-10 fix-gr-bg"><i class="ti-plus"></i><?php echo e(__('common.add_new')); ?></a></li>
                                        <?php if(permissionCheck('admin.giftcard.bulk_gift_card_upload_page')): ?>
                                        <li><a class="primary-btn radius_30px mr-10 fix-gr-bg" href="<?php echo e(route('admin.giftcard.bulk_gift_card_upload_page')); ?>"><i class="ti-plus"></i><?php echo e(__('product.bulk_upload')); ?></a></li>
                                        <?php endif; ?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="QA_section QA_section_heading_custom check_box_table">
                                <div class="QA_table">
                                    <!-- table-responsive -->
                                    <div class="" id="product_sku_div">
                                        <?php echo $__env->make('giftcard::giftcard.components._giftcard_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giftcard::giftcard.components._giftcard_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('giftcard::giftcard.components._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('backEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fightorsports/admin.fightorsports.com/Modules/GiftCard/Resources/views/giftcard/index.blade.php ENDPATH**/ ?>