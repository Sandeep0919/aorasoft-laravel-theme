<!-- ================Footer Area ================= -->
<footer class="footer-area pt-10 pb-20">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <p> <?php echo app('general_setting')->footer_copy_right; ?> </p>
            </div>
        </div>
    </div>
</footer>
<!-- ================End Footer Area ================= --><?php /**PATH /home/fightorsports/admin.fightorsports.com/resources/views/backEnd/partials/_footer.blade.php ENDPATH**/ ?>