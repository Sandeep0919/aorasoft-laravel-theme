<script src="<?php echo e(asset(asset_path('frontend/amazy/compile_js/app.js'))); ?>"></script>

 <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH /home/fightorsports/admin.fightorsports.com/resources/views/frontend/amazy/auth/partials/_scripts.blade.php ENDPATH**/ ?>