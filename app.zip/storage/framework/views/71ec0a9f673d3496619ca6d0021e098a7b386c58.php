
<?php echo $__env->make('backEnd.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/fightorsports/admin.fightorsports.com/resources/views/backEnd/partials/_header.blade.php ENDPATH**/ ?>